Tracker:AddItems("items/settings.json")
Tracker:AddItems("items/equips.json")
Tracker:AddItems("items/artifacts.json")

Tracker:AddMaps("maps/maps.json")

Tracker:AddLocations("locations/logic.json")
Tracker:AddLocations("locations/locations.json")

Tracker:AddLayouts("layouts/shared.json")
Tracker:AddLayouts("layouts/tracker.json")
Tracker:AddLayouts("layouts/broadcast.json")